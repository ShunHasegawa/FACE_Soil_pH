merModLmerTest <- setClass("merModLmerTest", contains = c("merMod", "lmerMod"))
#setOldClass("merModLmerTest", S4Class = "merModLmerTest")
  


